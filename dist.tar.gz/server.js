// server.ts
import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { initializeApp } from "firebase/app";
import {
  getFirestore,
  collection,
  query,
  where,
  getDocs,
  doc,
  setDoc,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp
} from "firebase/firestore";

// firebase-applet-config.json
var firebase_applet_config_default = {
  projectId: "youthful-atrium-zsmzh",
  appId: "1:932812571082:web:50baadc2faa3b66f9f0f33",
  apiKey: "AIzaSyDuqqBzGot6GNid9IFtNzZLj_2xsH5msco",
  authDomain: "youthful-atrium-zsmzh.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-worklogpro-6035ca9c-c91c-430f-9cfa-3936a2217049",
  storageBucket: "youthful-atrium-zsmzh.firebasestorage.app",
  messagingSenderId: "932812571082",
  measurementId: "",
  oAuthClientId: "932812571082-ajaaac50ctgtgebkfu272p7sbp97nkan.apps.googleusercontent.com",
  recaptchaSiteKey: ""
};

// server.ts
var firebaseApp = initializeApp(firebase_applet_config_default);
var db = getFirestore(firebaseApp, firebase_applet_config_default.firestoreDatabaseId);
async function startServer() {
  const app = express();
  app.use(express.json());
  async function sendTelegram(botToken, chatId, text) {
    try {
      const res = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          parse_mode: "Markdown"
        })
      });
      return await res.json();
    } catch (err) {
      console.error("Failed to send Telegram message:", err);
      return null;
    }
  }
  async function setupTelegramWebhook(token, hostUrl) {
    try {
      const webhookUrl = `${hostUrl}/api/telegram-webhook`;
      console.log(`Setting up Telegram webhook for URL: ${webhookUrl}`);
      const res = await fetch(`https://api.telegram.org/bot${token}/setWebhook?url=${webhookUrl}`);
      const data = await res.json();
      console.log("Telegram setWebhook response:", data);
      return data.ok;
    } catch (err) {
      console.error("Failed to set Telegram webhook:", err);
      return false;
    }
  }
  app.get("/api/settings", async (req, res) => {
    try {
      const settingsDoc = await getDoc(doc(db, "settings", "global"));
      if (settingsDoc.exists()) {
        res.json(settingsDoc.data());
      } else {
        res.json({ telegramBotToken: "", ownerChatId: "", businessPhone: "9400000000" });
      }
    } catch (err) {
      console.error("Error fetching settings:", err);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });
  app.post("/api/setup-telegram", async (req, res) => {
    try {
      const { token, chatId, businessPhone } = req.body;
      await setDoc(doc(db, "settings", "global"), {
        telegramBotToken: token ? token.trim() : "",
        ownerChatId: chatId ? String(chatId).trim() : "",
        businessPhone: businessPhone ? String(businessPhone).trim() : "9400000000",
        updatedAt: serverTimestamp()
      }, { merge: true });
      let webhookSuccess = false;
      if (token && token.trim()) {
        const hostUrl = process.env.APP_URL || `${req.protocol}://${req.get("host")}`;
        webhookSuccess = await setupTelegramWebhook(token.trim(), hostUrl);
        if (chatId) {
          await sendTelegram(
            token.trim(),
            chatId,
            `\u{1F389} *\u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D2E\u0D3E\u0D28\u0D47\u0D1C\u0D7C \u0D2C\u0D4B\u0D1F\u0D4D\u0D1F\u0D4D \u0D15\u0D23\u0D15\u0D4D\u0D31\u0D4D\u0D31\u0D3E\u0D2F\u0D3F! (Bot Connected)*

\u0D2E\u0D41\u0D24\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D4D\u0D15\u0D4D \u0D38\u0D4D\u0D35\u0D3E\u0D17\u0D24\u0D02! \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D7E \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D1A\u0D47\u0D7C\u0D15\u0D4D\u0D15\u0D41\u0D2E\u0D4D\u0D2A\u0D4B\u0D7E \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D28\u0D4B\u0D1F\u0D4D\u0D1F\u0D3F\u0D2B\u0D3F\u0D15\u0D4D\u0D15\u0D47\u0D37\u0D7B \u0D32\u0D2D\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D02. \u0D0F\u0D24\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D32\u0D41\u0D02 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D28\u0D2E\u0D4D\u0D2A\u0D7C (1 \u0D2E\u0D41\u0D24\u0D7D 50 \u0D35\u0D30\u0D46) \u0D05\u0D2F\u0D1A\u0D4D\u0D1A\u0D3E\u0D7D \u0D06 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D09\u0D1F\u0D7B \u0D32\u0D2D\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D3E\u0D23\u0D4D.`
          );
        }
      }
      res.json({
        success: true,
        webhookRegistered: webhookSuccess,
        message: webhookSuccess ? "Telegram bot saved and webhook registered successfully!" : "Settings saved, but failed to register webhook with Telegram."
      });
    } catch (error) {
      console.error("Error in /api/setup-telegram:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });
  app.post("/api/submit-work-log", async (req, res) => {
    try {
      const {
        workerNumber,
        workerName,
        workerPhone,
        date,
        siteName,
        workDescription,
        thachCount,
        vehicleRent,
        foodExpense,
        toolsRent,
        otherExpense,
        submittedBy
      } = req.body;
      const num = Number(workerNumber);
      if (!num || num < 1 || num > 50) {
        res.status(400).json({ error: "Worker number must be between 1 and 50" });
        return;
      }
      const payload = {
        workerNumber: num,
        workerName: String(workerName || "").trim(),
        workerPhone: String(workerPhone || "").trim(),
        date: String(date || "").trim(),
        siteName: String(siteName || "").trim(),
        workDescription: String(workDescription || "").trim(),
        thachCount: Number(thachCount) > 0 ? Number(thachCount) : 1,
        vehicleRent: Number(vehicleRent) || 0,
        foodExpense: Number(foodExpense) || 0,
        toolsRent: Number(toolsRent) || 0,
        otherExpense: Number(otherExpense) || 0,
        submittedBy: String(submittedBy || "").trim(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      const docRef = await addDoc(collection(db, "work_logs"), payload);
      const settingsDoc = await getDoc(doc(db, "settings", "global"));
      if (settingsDoc.exists()) {
        const { telegramBotToken, ownerChatId } = settingsDoc.data();
        if (telegramBotToken && ownerChatId) {
          const total = payload.vehicleRent + payload.foodExpense + payload.toolsRent + payload.otherExpense;
          const alertMsg = `\u{1F514} *\u0D2A\u0D41\u0D24\u0D3F\u0D2F \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D05\u0D2A\u0D4D\u200C\u0D21\u0D47\u0D31\u0D4D\u0D31\u0D4D! (New Work Entry)*

\u{1F477} *\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F #${payload.workerNumber}:* ${payload.workerName}
\u23F1\uFE0F *\u0D24\u0D1A\u0D4D\u0D1A\u0D4D (\u0D39\u0D3E\u0D1C\u0D7C):* ${payload.thachCount} \u0D24\u0D1A\u0D4D\u0D1A\u0D4D
\u{1F4C5} *\u0D24\u0D40\u0D2F\u0D24\u0D3F:* ${payload.date}
\u{1F4CD} *\u0D38\u0D48\u0D31\u0D4D\u0D31\u0D4D:* ${payload.siteName}
\u{1F6E0}\uFE0F *\u0D1C\u0D4B\u0D32\u0D3F \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E:* ${payload.workDescription}

\u{1F4B0} *\u0D1A\u0D3F\u0D32\u0D35\u0D41\u0D15\u0D7E (Expenses):*
  \u2022 \u0D35\u0D23\u0D4D\u0D1F\u0D3F \u0D35\u0D3E\u0D1F\u0D15: \u20B9${payload.vehicleRent}
  \u2022 \u0D2B\u0D41\u0D21\u0D4D \u0D0E\u0D15\u0D4D\u0D38\u0D4D\u0D2A\u0D46\u0D7B\u0D38\u0D4D: \u20B9${payload.foodExpense}
  \u2022 \u0D09\u0D2A\u0D15\u0D30\u0D23 \u0D35\u0D3E\u0D1F\u0D15: \u20B9${payload.toolsRent}
  \u2022 \u0D2E\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D3F\u0D32\u0D35\u0D41\u0D15\u0D7E: \u20B9${payload.otherExpense}
  \u{1F449} *\u0D06\u0D15\u0D46 \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${total}*

\u270D\uFE0F *\u0D30\u0D47\u0D16\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D41\u0D24\u0D4D\u0D24\u0D3F\u0D2F\u0D24\u0D4D:* ${payload.submittedBy || "\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F"}
_(\u0D15\u0D42\u0D1F\u0D41\u0D24\u0D7D \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E\u0D15\u0D4D\u0D15\u0D4D \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D28\u0D2E\u0D4D\u0D2A\u0D7C \u0D06\u0D2F ${payload.workerNumber} \u0D0E\u0D28\u0D4D\u0D28\u0D4D \u0D05\u0D2F\u0D15\u0D4D\u0D15\u0D41\u0D15)_`;
          sendTelegram(telegramBotToken, ownerChatId, alertMsg).catch((e) => console.error(e));
        }
      }
      res.json({ success: true, id: docRef.id });
    } catch (err) {
      console.error("Error submitting work log:", err);
      res.status(500).json({ error: "Failed to submit work log" });
    }
  });
  app.post("/api/update-work-log", async (req, res) => {
    try {
      const {
        id,
        workerNumber,
        workerName,
        date,
        siteName,
        workDescription,
        thachCount,
        vehicleRent,
        foodExpense,
        toolsRent,
        otherExpense,
        updatedBy
      } = req.body;
      if (!id) {
        res.status(400).json({ error: "Log ID is required" });
        return;
      }
      const num = Number(workerNumber);
      const updateData = {
        workerNumber: num,
        workerName: String(workerName || "").trim(),
        date: String(date || "").trim(),
        siteName: String(siteName || "").trim(),
        workDescription: String(workDescription || "").trim(),
        thachCount: Number(thachCount) > 0 ? Number(thachCount) : 1,
        vehicleRent: Number(vehicleRent) || 0,
        foodExpense: Number(foodExpense) || 0,
        toolsRent: Number(toolsRent) || 0,
        otherExpense: Number(otherExpense) || 0,
        updatedBy: String(updatedBy || "").trim(),
        updatedAt: serverTimestamp()
      };
      const docRef = doc(db, "work_logs", id);
      await updateDoc(docRef, updateData);
      const settingsDoc = await getDoc(doc(db, "settings", "global"));
      if (settingsDoc.exists()) {
        const { telegramBotToken, ownerChatId } = settingsDoc.data();
        if (telegramBotToken && ownerChatId) {
          const total = updateData.vehicleRent + updateData.foodExpense + updateData.toolsRent + updateData.otherExpense;
          const editMsg = `\u270F\uFE0F *\u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D31\u0D3F\u0D2A\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D4D \u0D0E\u0D21\u0D3F\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D41 (Report Updated)*

\u{1F477} *\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F #${updateData.workerNumber}:* ${updateData.workerName}
\u23F1\uFE0F *\u0D24\u0D1A\u0D4D\u0D1A\u0D4D:* ${updateData.thachCount} \u0D24\u0D1A\u0D4D\u0D1A\u0D4D
\u{1F4C5} *\u0D24\u0D40\u0D2F\u0D24\u0D3F:* ${updateData.date}
\u{1F4CD} *\u0D38\u0D48\u0D31\u0D4D\u0D31\u0D4D:* ${updateData.siteName}
\u{1F6E0}\uFE0F *\u0D1C\u0D4B\u0D32\u0D3F:* ${updateData.workDescription}
\u{1F4B0} *\u0D06\u0D15\u0D46 \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${total}*`;
          sendTelegram(telegramBotToken, ownerChatId, editMsg).catch((e) => console.error(e));
        }
      }
      res.json({ success: true });
    } catch (err) {
      console.error("Error updating work log:", err);
      res.status(500).json({ error: "Failed to update work log" });
    }
  });
  app.post("/api/delete-work-log", async (req, res) => {
    try {
      const { id, workerNumber, workerName } = req.body;
      if (!id) {
        res.status(400).json({ error: "Log ID is required" });
        return;
      }
      const docRef = doc(db, "work_logs", id);
      await deleteDoc(docRef);
      const settingsDoc = await getDoc(doc(db, "settings", "global"));
      if (settingsDoc.exists()) {
        const { telegramBotToken, ownerChatId } = settingsDoc.data();
        if (telegramBotToken && ownerChatId) {
          const delMsg = `\u{1F5D1}\uFE0F *\u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D31\u0D3F\u0D2A\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D4D \u0D2E\u0D3E\u0D2F\u0D4D\u200C\u0D1A\u0D4D\u0D1A\u0D41 (Report Deleted)*

\u{1F477} \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F #${workerNumber || ""} (${workerName || ""}) \u0D28\u0D4D\u0D31\u0D46 \u0D12\u0D30\u0D41 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D0E\u0D7B\u0D1F\u0D4D\u0D30\u0D3F \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D41\u0D02 \u0D21\u0D3F\u0D32\u0D40\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D3F\u0D1F\u0D4D\u0D1F\u0D41\u0D23\u0D4D\u0D1F\u0D4D.`;
          sendTelegram(telegramBotToken, ownerChatId, delMsg).catch((e) => console.error(e));
        }
      }
      res.json({ success: true });
    } catch (err) {
      console.error("Error deleting work log:", err);
      res.status(500).json({ error: "Failed to delete work log" });
    }
  });
  app.post("/api/submit-service-request", async (req, res) => {
    try {
      const {
        customerName,
        customerPhone,
        customerLocation,
        selectedServices,
        additionalDetails,
        preferredDate
      } = req.body;
      if (!customerName || !customerPhone) {
        res.status(400).json({ error: "\u0D2A\u0D47\u0D30\u0D41\u0D02 \u0D2B\u0D4B\u0D7A \u0D28\u0D2E\u0D4D\u0D2A\u0D31\u0D41\u0D02 \u0D28\u0D3F\u0D7C\u0D2C\u0D28\u0D4D\u0D27\u0D2E\u0D3E\u0D23\u0D4D" });
        return;
      }
      const servicesList = Array.isArray(selectedServices) ? selectedServices : [selectedServices || "\u0D2A\u0D46\u0D2F\u0D3F\u0D28\u0D4D\u0D31\u0D3F\u0D02\u0D17\u0D4D & \u0D15\u0D4D\u0D32\u0D40\u0D28\u0D3F\u0D02\u0D17\u0D4D"];
      const payload = {
        customerName: String(customerName).trim(),
        customerPhone: String(customerPhone).trim(),
        customerLocation: String(customerLocation || "\u0D15\u0D4B\u0D33\u0D2F\u0D3E\u0D1F\u0D4D / \u0D1A\u0D41\u0D31\u0D4D\u0D31\u0D33\u0D35\u0D3F\u0D7D").trim(),
        selectedServices: servicesList,
        additionalDetails: String(additionalDetails || "").trim(),
        preferredDate: String(preferredDate || "").trim(),
        status: "new",
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      const docRef = await addDoc(collection(db, "service_requests"), payload);
      const settingsDoc = await getDoc(doc(docRef.firestore, "settings", "global"));
      if (settingsDoc.exists()) {
        const { telegramBotToken, ownerChatId } = settingsDoc.data();
        if (telegramBotToken && ownerChatId) {
          const alertMsg = `\u{1F4E2} *\u0D2A\u0D41\u0D24\u0D3F\u0D2F \u0D15\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D2E\u0D7C \u0D15\u0D4B\u0D7E \u0D2C\u0D3E\u0D15\u0D4D\u0D15\u0D4D \u0D31\u0D3F\u0D15\u0D4D\u0D35\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D! (New Service Lead)*

\u{1F464} *\u0D15\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D2E\u0D7C \u0D2A\u0D47\u0D30\u0D4D:* ${payload.customerName}
\u{1F4DE} *\u0D2B\u0D4B\u0D7A \u0D28\u0D2E\u0D4D\u0D2A\u0D7C:* ${payload.customerPhone}
\u{1F4CD} *\u0D38\u0D4D\u0D25\u0D32\u0D02 / \u0D0F\u0D30\u0D3F\u0D2F:* ${payload.customerLocation}
\u{1F6E0}\uFE0F *\u0D06\u0D35\u0D36\u0D4D\u0D2F\u0D2E\u0D41\u0D33\u0D4D\u0D33 \u0D38\u0D47\u0D35\u0D28\u0D02:* ${payload.selectedServices.join(", ")}
` + (payload.preferredDate ? `\u{1F4C5} *\u0D09\u0D26\u0D4D\u0D26\u0D47\u0D36\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28 \u0D38\u0D2E\u0D2F\u0D02:* ${payload.preferredDate}
` : "") + (payload.additionalDetails ? `\u{1F4DD} *\u0D2E\u0D31\u0D4D\u0D31\u0D4D \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E:* ${payload.additionalDetails}
` : "") + `
\u{1F449} *\u0D09\u0D1F\u0D7B \u0D24\u0D28\u0D4D\u0D28\u0D46 \u0D15\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D2E\u0D31\u0D46 \u0D24\u0D3F\u0D30\u0D3F\u0D1A\u0D4D\u0D1A \u0D35\u0D3F\u0D33\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15!*`;
          sendTelegram(telegramBotToken, ownerChatId, alertMsg).catch((e) => console.error(e));
        }
      }
      res.json({ success: true, id: docRef.id });
    } catch (err) {
      console.error("Error submitting service request:", err);
      res.status(500).json({ error: "Failed to submit service request" });
    }
  });
  app.post("/api/update-service-request-status", async (req, res) => {
    try {
      const { id, status } = req.body;
      if (!id || !status) {
        res.status(400).json({ error: "ID and status required" });
        return;
      }
      const docRef = doc(db, "service_requests", id);
      await updateDoc(docRef, {
        status,
        updatedAt: serverTimestamp()
      });
      res.json({ success: true });
    } catch (err) {
      console.error("Error updating service request status:", err);
      res.status(500).json({ error: "Failed to update service request" });
    }
  });
  app.post("/api/update-service-request-schedule", async (req, res) => {
    try {
      const {
        id,
        scheduledDate,
        scheduledTime,
        assignedWorkerName,
        status,
        lat,
        lng,
        customerLocation
      } = req.body;
      if (!id) {
        res.status(400).json({ error: "ID required" });
        return;
      }
      const docRef = doc(db, "service_requests", id);
      const docSnap = await getDoc(docRef);
      const currentData = docSnap.exists() ? docSnap.data() : {};
      const updateData = {
        updatedAt: serverTimestamp()
      };
      if (scheduledDate !== void 0) updateData.scheduledDate = String(scheduledDate || "").trim();
      if (scheduledTime !== void 0) updateData.scheduledTime = String(scheduledTime || "").trim();
      if (assignedWorkerName !== void 0) updateData.assignedWorkerName = String(assignedWorkerName || "").trim();
      if (status !== void 0) updateData.status = status;
      if (lat !== void 0 && lat !== null) updateData.lat = Number(lat);
      if (lng !== void 0 && lng !== null) updateData.lng = Number(lng);
      if (customerLocation !== void 0) updateData.customerLocation = String(customerLocation || "").trim();
      await updateDoc(docRef, updateData);
      const settingsDoc = await getDoc(doc(db, "settings", "global"));
      if (settingsDoc.exists()) {
        const { telegramBotToken, ownerChatId } = settingsDoc.data();
        if (telegramBotToken && ownerChatId) {
          const customerName = currentData.customerName || "\u0D15\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D2E\u0D7C";
          const services = currentData.selectedServices ? currentData.selectedServices.join(", ") : "\u0D38\u0D47\u0D35\u0D28\u0D02";
          const schedMsg = `\u{1F5FA}\uFE0F *\u0D17\u0D42\u0D17\u0D3F\u0D7E \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D4D \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D37\u0D46\u0D21\u0D4D\u0D2F\u0D42\u0D7E \u0D05\u0D2A\u0D4D\u200C\u0D21\u0D47\u0D31\u0D4D\u0D31\u0D4D! (Work Scheduled)*

\u{1F464} *\u0D15\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D2E\u0D7C:* ${customerName}
\u{1F4CD} *\u0D38\u0D4D\u0D25\u0D32\u0D02:* ${updateData.customerLocation || currentData.customerLocation || "\u0D15\u0D4B\u0D33\u0D2F\u0D3E\u0D1F\u0D4D"}
\u{1F6E0}\uFE0F *\u0D38\u0D47\u0D35\u0D28\u0D02:* ${services}
\u{1F4C5} *\u0D37\u0D46\u0D21\u0D4D\u0D2F\u0D42\u0D7E \u0D24\u0D40\u0D2F\u0D24\u0D3F:* ${updateData.scheduledDate || "\u0D24\u0D40\u0D30\u0D41\u0D2E\u0D3E\u0D28\u0D3F\u0D1A\u0D4D\u0D1A\u0D3F\u0D1F\u0D4D\u0D1F\u0D3F\u0D32\u0D4D\u0D32"}
\u23F0 *\u0D38\u0D2E\u0D2F\u0D02:* ${updateData.scheduledTime || "\u0D32\u0D2D\u0D4D\u0D2F\u0D2E\u0D32\u0D4D\u0D32"}
\u{1F477} *\u0D1A\u0D41\u0D2E\u0D24\u0D32\u0D2F\u0D41\u0D33\u0D4D\u0D33 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F:* ${updateData.assignedWorkerName || "\u0D28\u0D3F\u0D2F\u0D2E\u0D3F\u0D1A\u0D4D\u0D1A\u0D3F\u0D1F\u0D4D\u0D1F\u0D3F\u0D32\u0D4D\u0D32"}
\u{1F4CC} *\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D3E\u0D31\u0D4D\u0D31\u0D38\u0D4D:* ${updateData.status || currentData.status}

` + (updateData.lat && updateData.lng ? `\u{1F4CD} [\u0D17\u0D42\u0D17\u0D3F\u0D7E \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D32\u0D4A\u0D15\u0D4D\u0D15\u0D47\u0D37\u0D7B \u0D24\u0D41\u0D31\u0D15\u0D4D\u0D15\u0D41\u0D15](https://www.google.com/maps/dir/?api=1&destination=${updateData.lat},${updateData.lng})` : "");
          sendTelegram(telegramBotToken, ownerChatId, schedMsg).catch((e) => console.error(e));
        }
      }
      res.json({ success: true });
    } catch (err) {
      console.error("Error updating service request schedule:", err);
      res.status(500).json({ error: "Failed to update schedule" });
    }
  });
  app.post("/api/delete-service-request", async (req, res) => {
    try {
      const { id } = req.body;
      if (!id) {
        res.status(400).json({ error: "ID required" });
        return;
      }
      const docRef = doc(db, "service_requests", id);
      await deleteDoc(docRef);
      res.json({ success: true });
    } catch (err) {
      console.error("Error deleting service request:", err);
      res.status(500).json({ error: "Failed to delete service request" });
    }
  });
  app.post("/api/telegram-webhook", async (req, res) => {
    try {
      const update = req.body;
      console.log("Received Telegram Update:", JSON.stringify(update));
      if (!update.message || !update.message.text) {
        res.sendStatus(200);
        return;
      }
      const chatId = update.message.chat.id;
      const rawText = update.message.text.trim();
      const text = rawText.toLowerCase();
      const settingsDoc = await getDoc(doc(db, "settings", "global"));
      const settings = settingsDoc.exists() ? settingsDoc.data() : null;
      const botToken = settings?.telegramBotToken;
      if (!botToken) {
        res.sendStatus(200);
        return;
      }
      const reply = async (msgText) => {
        await sendTelegram(botToken, chatId, msgText);
      };
      if (text === "/start" || text === "/help" || text === "help" || text === "\u0D38\u0D39\u0D3E\u0D2F\u0D02") {
        const welcomeMsg = `\u{1F6E0}\uFE0F *\u0D2E\u0D41\u0D24\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D4D\u0D15\u0D4D \u0D38\u0D4D\u0D35\u0D3E\u0D17\u0D24\u0D02! (Work Manager Bot)*

\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D7E \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D32\u0D42\u0D1F\u0D46 \u0D38\u0D2E\u0D7C\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28 \u0D1C\u0D4B\u0D32\u0D3F \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D33\u0D41\u0D02 \u0D1A\u0D3F\u0D32\u0D35\u0D41\u0D15\u0D33\u0D41\u0D02 \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D28\u0D3F\u0D2E\u0D3F\u0D37\u0D19\u0D4D\u0D19\u0D7E\u0D15\u0D4D\u0D15\u0D15\u0D02 \u0D05\u0D31\u0D3F\u0D2F\u0D3E\u0D02.

\u{1F4CB} *\u0D0E\u0D19\u0D4D\u0D19\u0D28\u0D46 \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D02?*
\u2022 *\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D28\u0D2E\u0D4D\u0D2A\u0D7C (1 \u0D2E\u0D41\u0D24\u0D7D 50 \u0D35\u0D30\u0D46)* \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D05\u0D2F\u0D1A\u0D4D\u0D1A\u0D3E\u0D7D \u0D06 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D2E\u0D41\u0D34\u0D41\u0D35\u0D7B \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D31\u0D3F\u0D2A\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D41\u0D02 \u0D1A\u0D3F\u0D32\u0D35\u0D41\u0D15\u0D33\u0D41\u0D02 \u0D32\u0D2D\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D02!
  _\u0D09\u0D26\u0D3E\u0D39\u0D30\u0D23\u0D24\u0D4D\u0D24\u0D3F\u0D28\u0D4D: 5 \u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D /5_

\u2022 \`/today\` - \u0D07\u0D28\u0D4D\u0D28\u0D24\u0D4D\u0D24\u0D46 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D33\u0D41\u0D02 \u0D06\u0D15\u0D46 \u0D1A\u0D3F\u0D32\u0D35\u0D41\u0D02
\u2022 \`/all\` - \u0D0E\u0D32\u0D4D\u0D32\u0D3E \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D33\u0D41\u0D1F\u0D46\u0D2F\u0D41\u0D02 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D26\u0D3F\u0D35\u0D38\u0D19\u0D4D\u0D19\u0D33\u0D41\u0D02 \u0D1A\u0D46\u0D32\u0D35\u0D41\u0D15\u0D33\u0D41\u0D02
\u2022 \`/month\` - \u0D08 \u0D2E\u0D3E\u0D38\u0D24\u0D4D\u0D24\u0D46 \u0D06\u0D15\u0D46 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D31\u0D3F\u0D2A\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D4D

----------------------------------
\u{1F4A1} _\u0D2E\u0D41\u0D24\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D1F\u0D46 Chat ID \u0D06\u0D23\u0D4D: \`${chatId}\`_ (\u0D07\u0D24\u0D4D \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D7D\u0D15\u0D3F\u0D2F\u0D3E\u0D7D \u0D2A\u0D41\u0D24\u0D3F\u0D2F \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D41\u0D15\u0D7E \u0D35\u0D30\u0D41\u0D2E\u0D4D\u0D2A\u0D4B\u0D7E \u0D24\u0D24\u0D4D\u0D38\u0D2E\u0D2F\u0D02 \u0D2E\u0D46\u0D38\u0D4D\u0D38\u0D47\u0D1C\u0D4D \u0D35\u0D30\u0D41\u0D02).`;
        await reply(welcomeMsg);
        res.sendStatus(200);
        return;
      }
      if (text === "/today" || text === "today" || text === "\u0D07\u0D28\u0D4D\u0D28\u0D4D") {
        const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
        const qToday = query(collection(db, "work_logs"), where("date", "==", todayStr));
        const snap = await getDocs(qToday);
        if (snap.empty) {
          await reply(`\u{1F4C5} *\u0D07\u0D28\u0D4D\u0D28\u0D4D (${todayStr}) \u0D06\u0D30\u0D41\u0D02 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D38\u0D2C\u0D4D\u0D2E\u0D3F\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D3F\u0D1F\u0D4D\u0D1F\u0D3F\u0D32\u0D4D\u0D32!*`);
          res.sendStatus(200);
          return;
        }
        let todayReport = `\u{1F4C5} *\u0D07\u0D28\u0D4D\u0D28\u0D24\u0D4D\u0D24\u0D46 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D31\u0D3F\u0D2A\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D4D (${todayStr})*

`;
        let totalVeh = 0, totalFd = 0, totalTl = 0, totalOth = 0, totalThachToday = 0;
        snap.forEach((d) => {
          const item = d.data();
          const v = Number(item.vehicleRent) || 0;
          const f = Number(item.foodExpense) || 0;
          const t = Number(item.toolsRent) || 0;
          const o = Number(item.otherExpense) || 0;
          const th = Number(item.thachCount) > 0 ? Number(item.thachCount) : 1;
          const subTotal = v + f + t + o;
          totalVeh += v;
          totalFd += f;
          totalTl += t;
          totalOth += o;
          totalThachToday += th;
          todayReport += `\u{1F477} *#${item.workerNumber} ${item.workerName}*
\u23F1\uFE0F \u0D39\u0D3E\u0D1C\u0D7C: ${th} \u0D24\u0D1A\u0D4D\u0D1A\u0D4D
\u{1F4CD} \u0D38\u0D48\u0D31\u0D4D\u0D31\u0D4D: ${item.siteName}
\u{1F6E0}\uFE0F \u0D1C\u0D4B\u0D32\u0D3F: ${item.workDescription}
\u{1F4B0} \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${subTotal} (\u0D35\u0D23\u0D4D\u0D1F\u0D3F: \u20B9${v}, \u0D2B\u0D41\u0D21\u0D4D: \u20B9${f}, \u0D09\u0D2A\u0D15\u0D30\u0D23\u0D02: \u20B9${t}, \u0D2E\u0D31\u0D4D\u0D31\u0D4D: \u20B9${o})
----------------------------------
`;
        });
        const grandTotal = totalVeh + totalFd + totalTl + totalOth;
        todayReport += `
\u23F1\uFE0F *\u0D06\u0D15\u0D46 \u0D24\u0D1A\u0D4D\u0D1A\u0D4D: ${totalThachToday} \u0D24\u0D1A\u0D4D\u0D1A\u0D4D*
\u{1F4B5} *\u0D07\u0D28\u0D4D\u0D28\u0D24\u0D4D\u0D24\u0D46 \u0D06\u0D15\u0D46 \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${grandTotal}*
(\u0D06\u0D15\u0D46 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D7E: ${snap.size})`;
        await reply(todayReport);
        res.sendStatus(200);
        return;
      }
      if (text === "/all" || text === "all" || text === "0" || text === "\u0D0E\u0D32\u0D4D\u0D32\u0D3E\u0D35\u0D30\u0D41\u0D02") {
        const snap = await getDocs(collection(db, "work_logs"));
        if (snap.empty) {
          await reply(`\u274C \u0D07\u0D24\u0D41\u0D35\u0D30\u0D46 \u0D12\u0D30\u0D41 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D02 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D38\u0D2C\u0D4D\u0D2E\u0D3F\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D3F\u0D1F\u0D4D\u0D1F\u0D3F\u0D32\u0D4D\u0D32.`);
          res.sendStatus(200);
          return;
        }
        const workerMap = {};
        snap.forEach((d) => {
          const data = d.data();
          const num = Number(data.workerNumber) || 0;
          const exp = (Number(data.vehicleRent) || 0) + (Number(data.foodExpense) || 0) + (Number(data.toolsRent) || 0) + (Number(data.otherExpense) || 0);
          const th = Number(data.thachCount) > 0 ? Number(data.thachCount) : 1;
          if (!workerMap[num]) {
            workerMap[num] = { name: data.workerName || `\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F ${num}`, count: 0, totalThach: 0, totalExp: 0 };
          }
          workerMap[num].count += 1;
          workerMap[num].totalThach += th;
          workerMap[num].totalExp += exp;
        });
        let allReport = `\u{1F465} *\u0D0E\u0D32\u0D4D\u0D32\u0D3E \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D33\u0D41\u0D1F\u0D46\u0D2F\u0D41\u0D02 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D38\u0D02\u0D17\u0D4D\u0D30\u0D39\u0D02 (Workers Summary)*

`;
        let overallExp = 0;
        let overallDays = 0;
        let overallThach = 0;
        const sortedNums = Object.keys(workerMap).map(Number).sort((a, b) => a - b);
        sortedNums.forEach((num) => {
          const item = workerMap[num];
          overallExp += item.totalExp;
          overallDays += item.count;
          overallThach += item.totalThach;
          allReport += `\u{1F477} *\u0D28\u0D2E\u0D4D\u0D2A\u0D7C #${num} - ${item.name}*
   \u2022 \u0D06\u0D15\u0D46 \u0D24\u0D1A\u0D4D\u0D1A\u0D4D: ${item.totalThach} \u0D24\u0D1A\u0D4D\u0D1A\u0D4D (${item.count} \u0D26\u0D3F\u0D35\u0D38\u0D02)
   \u2022 \u0D06\u0D15\u0D46 \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${item.totalExp}
   \u{1F449} \u0D35\u0D3F\u0D36\u0D26 \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E\u0D15\u0D4D\u0D15\u0D4D: \`/${num}\`

`;
        });
        allReport += `\u{1F4CA} *\u0D2E\u0D4A\u0D24\u0D4D\u0D24\u0D02 \u0D15\u0D23\u0D15\u0D4D\u0D15\u0D4D:*
\u2022 \u0D06\u0D15\u0D46 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D7E: ${sortedNums.length}
\u2022 \u0D06\u0D15\u0D46 \u0D24\u0D1A\u0D4D\u0D1A\u0D4D (Total Thach): ${overallThach} \u0D24\u0D1A\u0D4D\u0D1A\u0D4D
\u2022 \u0D06\u0D15\u0D46 \u0D1C\u0D4B\u0D32\u0D3F \u0D26\u0D3F\u0D35\u0D38\u0D19\u0D4D\u0D19\u0D7E: ${overallDays}
\u2022 \u0D06\u0D15\u0D46 \u0D2E\u0D4A\u0D24\u0D4D\u0D24\u0D02 \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${overallExp}`;
        await reply(allReport);
        res.sendStatus(200);
        return;
      }
      if (text === "/month" || text === "month" || text === "\u0D2E\u0D3E\u0D38\u0D02" || text === "\u0D08 \u0D2E\u0D3E\u0D38\u0D02") {
        const currentMonthPrefix = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
        const snap = await getDocs(collection(db, "work_logs"));
        const monthLogs = [];
        snap.forEach((d) => {
          const item = d.data();
          if (item.date && item.date.startsWith(currentMonthPrefix)) {
            monthLogs.push(item);
          }
        });
        if (monthLogs.length === 0) {
          await reply(`\u{1F4C5} \u0D08 \u0D2E\u0D3E\u0D38\u0D02 (${currentMonthPrefix}) \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D32\u0D2D\u0D4D\u0D2F\u0D2E\u0D32\u0D4D\u0D32.`);
          res.sendStatus(200);
          return;
        }
        let totalExp = 0;
        monthLogs.forEach((l) => {
          totalExp += (Number(l.vehicleRent) || 0) + (Number(l.foodExpense) || 0) + (Number(l.toolsRent) || 0) + (Number(l.otherExpense) || 0);
        });
        const uniqueWorkers = new Set(monthLogs.map((l) => l.workerNumber)).size;
        const monthReport = `\u{1F4C6} *\u0D08 \u0D2E\u0D3E\u0D38\u0D24\u0D4D\u0D24\u0D46 \u0D31\u0D3F\u0D2A\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D4D (${currentMonthPrefix})*

\u2022 \u0D06\u0D15\u0D46 \u0D1C\u0D4B\u0D32\u0D3F \u0D0E\u0D7B\u0D1F\u0D4D\u0D30\u0D3F\u0D15\u0D7E: ${monthLogs.length}
\u2022 \u0D1C\u0D4B\u0D32\u0D3F \u0D1A\u0D46\u0D2F\u0D4D\u0D24 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D7E: ${uniqueWorkers}
\u2022 \u0D06\u0D15\u0D46 \u0D35\u0D28\u0D4D\u0D28 \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${totalExp}

_\u0D0F\u0D24\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D32\u0D41\u0D02 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D35\u0D3F\u0D36\u0D26 \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E\u0D15\u0D4D\u0D15\u0D4D \u0D05\u0D35\u0D30\u0D41\u0D1F\u0D46 \u0D28\u0D2E\u0D4D\u0D2A\u0D7C (1-50) \u0D05\u0D2F\u0D15\u0D4D\u0D15\u0D41\u0D15._`;
        await reply(monthReport);
        res.sendStatus(200);
        return;
      }
      const cleanedNumberMatch = rawText.match(/^(?:\/|#|worker\s*|തൊഴിലാളി\s*)?([1-9]|[1-4][0-9]|50)$/i);
      let targetWorkerNumber = null;
      if (cleanedNumberMatch) {
        targetWorkerNumber = parseInt(cleanedNumberMatch[1], 10);
      } else {
        const onlyNum = parseInt(rawText.replace(/[^0-9]/g, ""), 10);
        if (!isNaN(onlyNum) && onlyNum >= 1 && onlyNum <= 50 && rawText.length <= 4) {
          targetWorkerNumber = onlyNum;
        }
      }
      if (targetWorkerNumber !== null) {
        console.log(`Searching work logs for Worker #${targetWorkerNumber}`);
        const q = query(collection(db, "work_logs"), where("workerNumber", "==", targetWorkerNumber));
        const snap = await getDocs(q);
        if (snap.empty) {
          const notFoundMsg = `\u274C *\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F #${targetWorkerNumber} \u0D28\u0D4D\u0D31\u0D46 \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D32\u0D2D\u0D4D\u0D2F\u0D2E\u0D32\u0D4D\u0D32!*

\u0D28\u0D2E\u0D4D\u0D2A\u0D7C #${targetWorkerNumber} \u0D09\u0D33\u0D4D\u0D33 \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F \u0D07\u0D24\u0D41\u0D35\u0D30\u0D46 \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D12\u0D28\u0D4D\u0D28\u0D41\u0D02 \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D30\u0D47\u0D16\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D41\u0D24\u0D4D\u0D24\u0D3F\u0D2F\u0D3F\u0D1F\u0D4D\u0D1F\u0D3F\u0D32\u0D4D\u0D32.

\u{1F449} \u0D2E\u0D31\u0D4D\u0D31\u0D47\u0D24\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D32\u0D41\u0D02 \u0D28\u0D2E\u0D4D\u0D2A\u0D7C (1 \u0D2E\u0D41\u0D24\u0D7D 50 \u0D35\u0D30\u0D46) \u0D28\u0D7D\u0D15\u0D3F \u0D28\u0D4B\u0D15\u0D4D\u0D15\u0D42.`;
          await reply(notFoundMsg);
          res.sendStatus(200);
          return;
        }
        const logs = [];
        snap.forEach((d) => {
          logs.push({ id: d.id, ...d.data() });
        });
        logs.sort((a, b) => (b.date || "").localeCompare(a.date || ""));
        const workerName = logs[0].workerName || `\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F #${targetWorkerNumber}`;
        let totalVehicle = 0;
        let totalFood = 0;
        let totalTools = 0;
        let totalOther = 0;
        let totalThach = 0;
        logs.forEach((log) => {
          const th = Number(log.thachCount) > 0 ? Number(log.thachCount) : 1;
          totalThach += th;
        });
        let logReport = `\u{1F4CB} *\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D31\u0D3F\u0D2A\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D4D (Worker #${targetWorkerNumber})*

\u{1F464} *\u0D2A\u0D47\u0D30\u0D4D:* ${workerName}
\u{1F522} *\u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F \u0D28\u0D2E\u0D4D\u0D2A\u0D7C:* #${targetWorkerNumber}
\u23F1\uFE0F *\u0D06\u0D15\u0D46 \u0D39\u0D3E\u0D1C\u0D7C (Thach):* ${totalThach} \u0D24\u0D1A\u0D4D\u0D1A\u0D4D (${logs.length} \u0D26\u0D3F\u0D35\u0D38\u0D02)
==================================

`;
        logs.forEach((log, index) => {
          const vehicle = Number(log.vehicleRent) || 0;
          const food = Number(log.foodExpense) || 0;
          const tools = Number(log.toolsRent) || 0;
          const other = Number(log.otherExpense) || 0;
          const th = Number(log.thachCount) > 0 ? Number(log.thachCount) : 1;
          const logTotal = vehicle + food + tools + other;
          totalVehicle += vehicle;
          totalFood += food;
          totalTools += tools;
          totalOther += other;
          logReport += `${index + 1}. \u{1F4C5} *\u0D24\u0D40\u0D2F\u0D24\u0D3F:* ${log.date}
   \u23F1\uFE0F *\u0D24\u0D1A\u0D4D\u0D1A\u0D4D:* ${th} \u0D24\u0D1A\u0D4D\u0D1A\u0D4D
   \u{1F4CD} *\u0D38\u0D48\u0D31\u0D4D\u0D31\u0D4D:* ${log.siteName}
   \u{1F6E0}\uFE0F *\u0D1C\u0D4B\u0D32\u0D3F:* ${log.workDescription}
   \u{1F4B0} *\u0D1A\u0D3F\u0D32\u0D35\u0D41\u0D15\u0D7E:*
      \u2022 \u0D35\u0D23\u0D4D\u0D1F\u0D3F \u0D35\u0D3E\u0D1F\u0D15: \u20B9${vehicle}
      \u2022 \u0D2B\u0D41\u0D21\u0D4D: \u20B9${food}
      \u2022 \u0D09\u0D2A\u0D15\u0D30\u0D23\u0D19\u0D4D\u0D19\u0D7E: \u20B9${tools}
      \u2022 \u0D2E\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D3F\u0D32\u0D35\u0D41\u0D15\u0D7E: \u20B9${other}
      \u{1F449} *\u0D26\u0D3F\u0D35\u0D38\u0D24\u0D4D\u0D24\u0D46 \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${logTotal}*
`;
          if (log.submittedBy) {
            logReport += `   \u270D\uFE0F _\u0D30\u0D47\u0D16\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D41\u0D24\u0D4D\u0D24\u0D3F\u0D2F\u0D24\u0D4D: ${log.submittedBy}_
`;
          }
          logReport += `----------------------------------

`;
        });
        const grandTotal = totalVehicle + totalFood + totalTools + totalOther;
        logReport += `\u{1F4C8} *\u0D06\u0D15\u0D46 \u0D1A\u0D3F\u0D32\u0D35\u0D4D \u0D38\u0D02\u0D17\u0D4D\u0D30\u0D39\u0D02 (Worker #${targetWorkerNumber}):*
\u{1F699} \u0D35\u0D23\u0D4D\u0D1F\u0D3F \u0D35\u0D3E\u0D1F\u0D15: \u20B9${totalVehicle}
\u{1F372} \u0D2B\u0D41\u0D21\u0D4D \u0D0E\u0D15\u0D4D\u0D38\u0D4D\u0D2A\u0D46\u0D7B\u0D38\u0D4D: \u20B9${totalFood}
\u{1F527} \u0D09\u0D2A\u0D15\u0D30\u0D23 \u0D35\u0D3E\u0D1F\u0D15: \u20B9${totalTools}
\u{1F4DD} \u0D2E\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D3F\u0D32\u0D35\u0D41\u0D15\u0D7E: \u20B9${totalOther}

\u{1F4B0} *\u0D06\u0D15\u0D46 \u0D2E\u0D4A\u0D24\u0D4D\u0D24\u0D02 \u0D1A\u0D3F\u0D32\u0D35\u0D4D: \u20B9${grandTotal}*`;
        if (logReport.length > 4e3) {
          logReport = logReport.substring(0, 3900) + "\n\n... (\u0D2C\u0D3E\u0D15\u0D4D\u0D15\u0D3F \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D32\u0D3F\u0D2E\u0D3F\u0D31\u0D4D\u0D31\u0D4D \u0D15\u0D3E\u0D30\u0D23\u0D02 \u0D1A\u0D41\u0D30\u0D41\u0D15\u0D4D\u0D15\u0D3F)";
        }
        await reply(logReport);
        res.sendStatus(200);
        return;
      }
      const helpMsg = `\u26A0\uFE0F *\u0D15\u0D2E\u0D3E\u0D7B\u0D21\u0D4D \u0D35\u0D4D\u0D2F\u0D15\u0D4D\u0D24\u0D2E\u0D32\u0D4D\u0D32!*

\u0D2E\u0D41\u0D24\u0D32\u0D3E\u0D33\u0D3F, \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D31\u0D3F\u0D2A\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D4D \u0D32\u0D2D\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D7B \u0D05\u0D35\u0D30\u0D41\u0D1F\u0D46 \u0D28\u0D2E\u0D4D\u0D2A\u0D7C \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D02 \u0D05\u0D2F\u0D15\u0D4D\u0D15\u0D41\u0D15.
\u0D09\u0D26\u0D3E\u0D39\u0D30\u0D23\u0D24\u0D4D\u0D24\u0D3F\u0D28\u0D4D: *5* \u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D */5* (1 \u0D2E\u0D41\u0D24\u0D7D 50 \u0D35\u0D30\u0D46).

\u2022 \`/today\` - \u0D07\u0D28\u0D4D\u0D28\u0D24\u0D4D\u0D24\u0D46 \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E
\u2022 \`/all\` - \u0D0E\u0D32\u0D4D\u0D32\u0D3E \u0D24\u0D4A\u0D34\u0D3F\u0D32\u0D3E\u0D33\u0D3F\u0D15\u0D33\u0D41\u0D1F\u0D46\u0D2F\u0D41\u0D02 \u0D15\u0D23\u0D15\u0D4D\u0D15\u0D41\u0D15\u0D7E`;
      await reply(helpMsg);
      res.sendStatus(200);
    } catch (error) {
      console.error("Error in Telegram Webhook:", error);
      res.sendStatus(200);
    }
  });
  const hasDist = fs.existsSync(path.resolve(process.cwd(), "dist/index.html"));
  if (hasDist) {
    console.log("Serving production build from dist directory");
    const distDir = path.resolve(process.cwd(), "dist");
    app.use(express.static(distDir));
    app.get("*", (req, res) => {
      if (req.path.startsWith("/api")) {
        res.status(404).json({ error: "API route not found" });
        return;
      }
      res.sendFile(path.resolve(distDir, "index.html"));
    });
  } else {
    console.log("Serving development mode with Vite middleware");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
    app.use("*", async (req, res, next) => {
      if (req.originalUrl.startsWith("/api")) {
        res.status(404).json({ error: "API route not found" });
        return;
      }
      try {
        const indexPath = path.resolve(process.cwd(), "index.html");
        let template = fs.readFileSync(indexPath, "utf-8");
        template = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ "Content-Type": "text/html" }).send(template);
      } catch (e) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  }
  const port = Number(process.env.PORT) || 3e3;
  app.listen(port, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${port}`);
  });
}
startServer();
